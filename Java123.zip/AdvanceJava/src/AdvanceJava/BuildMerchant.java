package AdvanceJava;

import java.util.ArrayList;

//We have multiple Merchants. One Merchant can have amount of Transaction and merchant_Legalname. Build merch and Retrieve in another Class. 

public class BuildMerchant {
	ArrayList<Merchant> build(){
		ArrayList<Merchant> listmerch = new ArrayList<Merchant>();
		listmerch.add(new Merchant(21,"Inforys"));
		listmerch.add(new Merchant(22,"TCS"));
		listmerch.add(new Merchant(23,"Wipro"));
		return listmerch;
		}
}