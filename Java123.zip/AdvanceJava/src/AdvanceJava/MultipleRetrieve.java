package AdvanceJava;
//I Need Multiple Merchants every merchant have his legalname and Transaction, Transaction means Transaction_Id and Transaction_Location.

import java.util.ArrayList;

public class MultipleRetrieve {
	public static void main(String[] args) {
		MultipleBuildMerchant bm=new MultipleBuildMerchant();
		ArrayList<MultipleMerchant> merchlist = bm.build();
		
		for(MultipleMerchant mm:merchlist){
			System.out.println(mm);
			
			int transactionCount = mm.getTransactionCount();
			System.out.println(transactionCount);
			
			String legalName = mm.getLegalName();
			System.out.println(legalName);
			
			Transaction transaction = mm.getTransaction();
			System.out.println(transaction.getTransaction_id());
			System.out.println(transaction.getTransaction_location());
		}
	}

}
