package AdvanceJava;

import java.util.ArrayList;

public class FetchStudent {
	public static void main(String[] args) {
	MakeStudent stud1=new MakeStudent();
	ArrayList<Student> student=stud1.build();
	
	for(Student ss:student){
		System.out.println(ss);
		
	int age=ss.getAge();
	System.out.println(ss.getAge());
	}
}
}
