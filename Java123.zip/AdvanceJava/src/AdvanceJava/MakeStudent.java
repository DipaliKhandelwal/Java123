package AdvanceJava;

import java.util.ArrayList;

public class MakeStudent {
	ArrayList<Student> build(){
	ArrayList<Student> stud=new ArrayList<Student>();
	stud.add(new Student(2));
	stud.add(new Student(3));
	stud.add(new Student(4));
	return stud;
	}
}
