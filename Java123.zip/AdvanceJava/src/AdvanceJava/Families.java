package AdvanceJava;
//I Need multiple Families every family have his Guardian and count of members, Guardian means name and age.

public class Families {
	private Guardian guardian;
	private int count_of_number;
	
	public Guardian getGuardian() {
		return guardian;
	}
	public void setGuardian(Guardian guardian) {
		this.guardian = guardian;
	}
	public int getCount_of_number() {
		return count_of_number;
	}
	public void setCount_of_number(int count_of_number) {
		this.count_of_number = count_of_number;
	}
	public Families(Guardian guardian, int count_of_number) {
		super();
		this.guardian = guardian;
		this.count_of_number = count_of_number;
	}
	
	public Families(String string, int i, int j) {}
		
	@Override
	public String toString() {
		return "Families [guardian=" + guardian + ", count_of_number=" + count_of_number + "]";
	}
}
