package AdvanceJava;
//I Need multiple Families every family have his Guardian and count of members, Guardian means name and age.

import java.util.ArrayList;

public class BuildFamilies {

	ArrayList<Families> build(){
	ArrayList<Families>	fam=new ArrayList<Families>();
	//we create object of Guardian class 
	Guardian g1=new Guardian("ABC",2);
	Guardian g2=new Guardian("PQR",3);
	//we create object of Families class
	Families f1=new Families(g1,2);
	Families f2=new Families(g2,4);
	fam.add(f1);
	fam.add(f2);
	return fam;
		
	}
}
