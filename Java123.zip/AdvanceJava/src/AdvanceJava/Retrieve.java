package AdvanceJava;

//We have multiple Merchants. One Merchant can have amount of Transaction and merchant_Legalname. Build merch and Retrieve in another Class. 

import java.util.ArrayList;

public class Retrieve {
	public static void main(String[] args) {
		BuildMerchant bm=new BuildMerchant();
		ArrayList<Merchant> merchlist = bm.build();
		
		for(Merchant mm:merchlist){
			System.out.println(mm);
			System.out.println(mm.getTransactionCount());
			System.out.println(mm.getLegalName());
			}
	}
}
