package AdvanceJava;
//Build Customer.....One Customer can have Customer_Name and Phone_Number.
public class Customer {
 private String customer_Name;
 private int phone_Number;
 
 	//getter setter method 
	public String getCustomer_Name() {
	return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
	this.customer_Name = customer_Name;
	}
	public int getPhone_Number() {
	return phone_Number;
	}
	public void setPhone_Number(int phone_Number) {
	this.phone_Number = phone_Number;
	}
 
	//Constructors
	public Customer(String customer_Name, int phone_Number) {
		super();
		this.customer_Name = customer_Name;
		this.phone_Number = phone_Number;
	}
	
	@Override
	public String toString() {
		return "Student [customer_Name=" + customer_Name + ", phone_Number=" + phone_Number + "]";
	}
 	
}
