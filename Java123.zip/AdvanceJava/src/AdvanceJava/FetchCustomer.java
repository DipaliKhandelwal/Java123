 package AdvanceJava;

import java.util.ArrayList;

//Build Customer.....One Customer can have Customer_Name and Phone_Number.

public class FetchCustomer {
	public static void main(String[] args) {
		BuildCustomer cust1=new BuildCustomer();
		ArrayList<Customer> customer= cust1.build();
		
		for(Customer cc:customer){
			System.out.println(cc);
			
			String customer_Name=cc.getCustomer_Name();
			System.out.println(cc.getCustomer_Name());
			
			int phone_Number=cc.getPhone_Number();
			System.out.println(cc.getPhone_Number());
		}
	}

}
