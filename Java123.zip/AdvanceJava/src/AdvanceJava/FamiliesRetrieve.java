package AdvanceJava;
//I Need multiple Families every family have his Guardian and count of members, Guardian means name and age.

import java.util.ArrayList;

public class FamiliesRetrieve {
	public static void main(String[] args) {
		BuildFamilies bf=new BuildFamilies();
		ArrayList<Families> families = bf.build();
		
		for(Families ff:families){
			System.out.println(ff);
			
			int count_of_number=ff.getCount_of_number();
			System.out.println(count_of_number);
			
			Guardian guardian=ff.getGuardian();
			System.out.println(guardian.getName());
			System.out.println(guardian.getAge());
		}
	}

}
