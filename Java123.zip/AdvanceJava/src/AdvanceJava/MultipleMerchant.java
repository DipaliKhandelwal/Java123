package AdvanceJava;

//I Need Multiple Merchants every merchant have his legalname and Transaction, Transaction means Transaction_Id and Transaction_Location.

public class MultipleMerchant {
	private int transactionCount;
	private String legalName;
	private Transaction transaction;
	
	//getter setter method
	public int getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(int transactionCount) {
		this.transactionCount = transactionCount;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
	//Constructors
	public MultipleMerchant(int transactionCount, String legalName, Transaction transaction) {
		super();
		this.transactionCount = transactionCount;
		this.legalName = legalName;
		this.transaction = transaction;
	}
	
	//public MultipleMerchant(String string, Transaction t1) {
		// TODO Auto-generated constructor stub }
	
	@Override
	public String toString() {
		return "MultipleMerchant [transactionCount=" + transactionCount + ", legalName=" + legalName + ", transaction="
				+ transaction + "]";
	}
	
	
	
	

}
