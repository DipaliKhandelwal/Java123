package AdvanceJava;

//We have multiple Merchants. One Merchant can have amount of Transaction and merchant_Legalname. Build merch and Retrieve in another Class. 

public class Merchant {
	private int transactionCount;
	private String legalName;
	public Merchant(int transactionCount, String legalName) {
		super();
		this.transactionCount = transactionCount;
		this.legalName = legalName;
	}
	public int getTransactionCount() {
		return transactionCount;
	}
	public void setTransactionCount(int transactionCount) {
		this.transactionCount = transactionCount;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	@Override
	public String toString() {
		return "Marchant [transactionCount=" + transactionCount + ", legalName=" + legalName + "]";
	}
}
