package AdvanceJava;

import java.util.ArrayList;

//Build Customer.....One Customer can have Customer_Name and Phone_Number.

public class BuildCustomer {
	ArrayList<Customer> build(){
	ArrayList<Customer> cust=new ArrayList<Customer>();
		
	cust.add(new Customer("Ruby",101));	
	cust.add(new Customer("Arun",102));	
	cust.add(new Customer("Rima",103));	
	return cust;
	}
}
