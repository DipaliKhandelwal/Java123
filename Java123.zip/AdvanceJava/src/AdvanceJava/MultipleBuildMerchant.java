package AdvanceJava;

import java.util.ArrayList;

//I Need Multiple Merchants every merchant have his legalname and Transaction, Transaction means Transaction_Id and Transaction_Location.

public class MultipleBuildMerchant {
	
	ArrayList<MultipleMerchant> build(){
		ArrayList<MultipleMerchant> listmerch=new ArrayList<MultipleMerchant>();
		
		//we create object of transation class 
		Transaction t1=new Transaction(11,"Aurangabad");
		Transaction t2=new Transaction(12,"Jafrabad");
		//we create object of MultipleMerchant class
		MultipleMerchant m1=new MultipleMerchant(1, "XYZ",t1);
		MultipleMerchant m2=new MultipleMerchant(2, "ABC",t2);
		listmerch.add(m1);
		listmerch.add(m2);
		return listmerch;
	}

}
