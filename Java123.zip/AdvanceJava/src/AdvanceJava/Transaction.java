package AdvanceJava;

//I Need Multiple Merchants every merchant have his legalname and Transaction, Transaction means Transaction_Id and Transaction_Location.

public class Transaction {
	private int transaction_id;
	private String transaction_location;
	
	//getter setter method 
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_location() {
		return transaction_location;
	}
	public void setTransaction_location(String transaction_location) {
		this.transaction_location = transaction_location;
	}
	
	//Constructors
	public Transaction(int transaction_id, String transaction_location) {
		super();
		this.transaction_id = transaction_id;
		this.transaction_location = transaction_location;
	}
	
	@Override
	public String toString() {
		return "Transaction [transaction_id=" + transaction_id + ", transaction_location=" + transaction_location + "]";
	}
	
	
	

}
